package com.examen.DiegoRodriguezExamen.Controllers;

import com.examen.DiegoRodriguezExamen.Models.Region;
import com.examen.DiegoRodriguezExamen.Repositories.RegionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class RegionController {

    @Autowired
    private RegionRepository regionRepository;

    @GetMapping("/InsertarRegion")
    public String mostrarFormularioRegion(Model model) {
        model.addAttribute("region", new Region());
        return "InsertarRegion";
    }

    @PostMapping("/InsertarRegion")
    public String insertarRegion(@ModelAttribute Region region) {
        regionRepository.insertarRegion(region);
        return "redirect:/InsertarRegion";
    }

    @GetMapping("/ListaRegion")
    public String ListaRegion(Model model) {
        List<Region> regiones = regionRepository.findAll();
    
        // Agregar la lista al modelo para que sea accesible en la vista
        model.addAttribute("regiones", regiones);
    
        // Devolver el nombre de la vista Thymeleaf
        return "ListaRegion";
    }

    @PostMapping("/EliminarRegion")
    public String EliminarRegion(@RequestParam("id") long id) {
        // Obtener la región por su ID
        Region region = regionRepository.findById(id);
        if (region != null) {
            // Llamar al método en el repositorio para eliminar la región
            regionRepository.EliminarRegion(id);
        }
        return "redirect:/ListaRegion";
    }
}