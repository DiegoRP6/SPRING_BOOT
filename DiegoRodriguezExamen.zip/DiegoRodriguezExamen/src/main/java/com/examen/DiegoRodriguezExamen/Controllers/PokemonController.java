package com.examen.DiegoRodriguezExamen.Controllers;

import com.examen.DiegoRodriguezExamen.Models.Entrenador;
import com.examen.DiegoRodriguezExamen.Models.Pokemon;
import com.examen.DiegoRodriguezExamen.Models.Region;
import com.examen.DiegoRodriguezExamen.Repositories.EntrenadorRepository;
import com.examen.DiegoRodriguezExamen.Repositories.PokemonRepository;
import com.examen.DiegoRodriguezExamen.Repositories.RegionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class PokemonController {

    @Autowired
    private PokemonRepository pokemonRepository;

    @Autowired
    private RegionRepository regionRepository;

    @Autowired
    private EntrenadorRepository entrenadorRepository;

    @GetMapping("/InsertarPokemon")
    public String mostrarFormularioPokemon(Model model) {
        model.addAttribute("pokemon", new Pokemon());

        // Cargar la lista de regiones desde el repositorio
        List<Region> regiones = regionRepository.findAll();
        model.addAttribute("regiones", regiones);

        // Cargar la lista de regiones desde el repositorio
        List<Entrenador> entrenadores = entrenadorRepository.findAll();
        model.addAttribute("entrenadores", entrenadores);

        return "InsertarPokemon";
    }

    @PostMapping("/InsertarPokemon")
    public String InsertarPokemon(@ModelAttribute Pokemon pokemon) {
        pokemonRepository.InsertarPokemon(pokemon);
        return "redirect:/InsertarPokemon"; 
    }

    @GetMapping("/ListaPokemon")
    public String ListaPokemon(Model model) {
        List<Pokemon> pokemons = pokemonRepository.findAll();
    
        // Agregar la lista al modelo para que sea accesible en la vista
        model.addAttribute("pokemons", pokemons);
    
        // Devolver el nombre de la vista Thymeleaf
        return "ListaPokemon";
    }

    @RequestMapping("/EliminarPokemon")
    public String EliminarPokemon(Integer id) {
        pokemonRepository.EliminarPokemon(id);
        return "redirect:/ListaPokemon";
    }
}