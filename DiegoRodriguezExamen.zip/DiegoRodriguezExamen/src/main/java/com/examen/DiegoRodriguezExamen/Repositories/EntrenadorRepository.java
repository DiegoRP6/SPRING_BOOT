package com.examen.DiegoRodriguezExamen.Repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.examen.DiegoRodriguezExamen.Models.Entrenador;
import com.examen.DiegoRodriguezExamen.Models.Pokemon;

import java.util.List;

@Repository
public class EntrenadorRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Entrenador> findAll() {
        String query = "SELECT * FROM ENTRENADOR";
        return jdbcTemplate.query(query, (resultSet, rowNum) -> {
            Entrenador entrenador = new Entrenador();
            entrenador.setId(resultSet.getLong("id"));
            entrenador.setNombre(resultSet.getString("nombre"));
            // Puedes agregar más campos según sea necesario
            return entrenador;
        });
    }

    public void insertarEntrenador(Entrenador entrenador) {
        String query = "INSERT INTO ENTRENADOR (nombre) VALUES (?)";
        jdbcTemplate.update(query, entrenador.getNombre());
    }

    public Entrenador findById(long id) {
        String query = "SELECT * FROM ENTRENADOR WHERE id = ?";
        return jdbcTemplate.queryForObject(query, new Object[]{id}, (resultSet, rowNum) -> {
            Entrenador entrenador = new Entrenador();
            entrenador.setId(resultSet.getLong("id"));
            entrenador.setNombre(resultSet.getString("nombre"));
            return entrenador;
        });

    }

    public void guardarEntrenador(Entrenador entrenador) {
        String query = "UPDATE ENTRENADOR SET active = ? WHERE id = ?";
        jdbcTemplate.update(query, entrenador.isActive(), entrenador.getId());
    }

    public void desactivarTodos() {
        String query = "UPDATE ENTRENADOR SET active = false";
        jdbcTemplate.update(query);
    }

    public List<Pokemon> findPokemonsByEntrenadorId(long entrenadorId) {
        String query = "SELECT * FROM POKEMON WHERE entrenador_id = ?";
        return jdbcTemplate.query(query, new Object[]{entrenadorId}, (resultSet, rowNum) -> {
            Pokemon pokemon = new Pokemon();
            pokemon.setId(resultSet.getLong("id"));
            pokemon.setNombre(resultSet.getString("nombre"));
            // Puedes agregar más campos según sea necesario
            return pokemon;
        });
    }


}