package com.examen.DiegoRodriguezExamen.Repositories;

import com.examen.DiegoRodriguezExamen.Models.Region;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RegionRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Region> findAll() {
        String query = "SELECT * FROM REGION";
        return jdbcTemplate.query(query, (resultSet, rowNum) -> {
            Region region = new Region();
            region.setId(resultSet.getLong("id"));
            region.setNombre(resultSet.getString("nombre"));
            return region;
        });
    }
    
    public void insertarRegion(Region region) {
        String query = "INSERT INTO REGION (nombre) VALUES (?)";
        jdbcTemplate.update(query, region.getNombre());
    }

    public Region findById(long id) {
        String query = "SELECT * FROM REGION WHERE id = ?";
        return jdbcTemplate.queryForObject(query, new Object[]{id}, (resultSet, rowNum) -> {
            Region region = new Region();
            region.setId(resultSet.getLong("id"));
            region.setNombre(resultSet.getString("nombre"));
            return region;
        });

    }

    public void EliminarRegion(long id) {
        String query = "DELETE FROM REGION WHERE id = ?";
        jdbcTemplate.update(query, id);
    }
}