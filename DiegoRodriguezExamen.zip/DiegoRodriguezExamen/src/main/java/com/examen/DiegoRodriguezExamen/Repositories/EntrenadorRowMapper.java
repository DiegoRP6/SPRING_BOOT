package com.examen.DiegoRodriguezExamen.Repositories;

import com.examen.DiegoRodriguezExamen.Models.Entrenador;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EntrenadorRowMapper implements RowMapper<Entrenador> {

    @Override
    public Entrenador mapRow(ResultSet rs, int rowNum) throws SQLException {
        Entrenador entrenador = new Entrenador();
        entrenador.setId(rs.getLong("id"));
        entrenador.setNombre(rs.getString("nombre"));
        entrenador.setActive(rs.getBoolean("active"));
        return entrenador;
    }
}
