package com.examen.DiegoRodriguezExamen.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.examen.DiegoRodriguezExamen.Models.Entrenador;
import com.examen.DiegoRodriguezExamen.Models.Pokemon;
import com.examen.DiegoRodriguezExamen.Repositories.EntrenadorRepository;

@Controller
public class EntrenadorController {

    @Autowired
    private EntrenadorRepository entrenadorRepository;



    @GetMapping("/")
    public String mostrarIndex(Model model) {
        // Obtén la lista de entrenadores y agrégala al modelo
        List<Entrenador> entrenadores = entrenadorRepository.findAll();
        model.addAttribute("entrenadores", entrenadores);
        return "index";
    }

    @PostMapping("/ActivarEntrenador")
    public String activarEntrenador(@RequestParam("id") long id) {
        // Desactivar todos los entrenadores
        entrenadorRepository.desactivarTodos();
    
        // Obtener el entrenador por su ID
        Entrenador entrenador = entrenadorRepository.findById(id);
    
        // Activar el entrenador específico
        entrenador.setActive(true);
    
        // Guardar los cambios en el repositorio (o servicio, dependiendo de tu estructura)
        entrenadorRepository.guardarEntrenador(entrenador);
    
        // Redirigir a la página principal u otra página después de la activación
        return "redirect:/";
    }

    @GetMapping("/PokemonEntrenador")
    public String PokemonEntrenador(@RequestParam("id") long id, Model model) {
        // Lógica para obtener los pokemons del entrenador con el ID proporcionado
        List<Pokemon> pokemones = entrenadorRepository.findPokemonsByEntrenadorId(id);
        model.addAttribute("pokemones", pokemones);
        return "PokemonEntrenador";
    }

}
