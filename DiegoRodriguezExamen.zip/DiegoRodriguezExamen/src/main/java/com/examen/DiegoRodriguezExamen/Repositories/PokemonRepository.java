package com.examen.DiegoRodriguezExamen.Repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.examen.DiegoRodriguezExamen.Models.Pokemon;

@Repository
public class PokemonRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void InsertarPokemon(Pokemon pokemon) {
        String query = "INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES (?, ?, ?)";
        jdbcTemplate.update(query, pokemon.getNombre(), pokemon.getRegion(), pokemon.getEntrenadorId());
        
    }

    public List<Pokemon> findAll() {
        String query = "SELECT * FROM POKEMON;";
        return jdbcTemplate.query(query, new PokemonRowMapper());
    }

    public Pokemon findById(int id) {
        String query = "SELECT * FROM POKEMON WHERE id = ?;";
        return jdbcTemplate.queryForObject(query, new PokemonRowMapper(), id);
    }

    public void EliminarPokemon(int id) {
        String query = "DELETE FROM POKEMON WHERE id = ?;";
        jdbcTemplate.update(query, id);
    }
}
