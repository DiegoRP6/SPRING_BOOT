package com.examen.DiegoRodriguezExamen.Models;

import java.util.List;

public class Region {

    private long id;
    private String nombre;
    private List<Pokemon> pokemons;
    // Constructor por defecto
    public Region() {
    }

    // Constructor con parámetros
    public Region(long id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    // Getters y setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Pokemon> getPokemons() {
        return pokemons;
    }

    public void setPokemons(List<Pokemon> pokemons) {
        this.pokemons = pokemons;
    }

}