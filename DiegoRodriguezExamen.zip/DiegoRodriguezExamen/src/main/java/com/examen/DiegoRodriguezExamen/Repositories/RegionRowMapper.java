package com.examen.DiegoRodriguezExamen.Repositories;

import org.springframework.jdbc.core.RowMapper;

import com.examen.DiegoRodriguezExamen.Models.Region;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RegionRowMapper implements RowMapper<Region> {

    @Override
    public Region mapRow(ResultSet rs, int rowNum) throws SQLException {
        Region region = new Region();
        region.setId(rs.getLong("id"));
        region.setNombre(rs.getString("nombre"));
        return region;
    }
}
