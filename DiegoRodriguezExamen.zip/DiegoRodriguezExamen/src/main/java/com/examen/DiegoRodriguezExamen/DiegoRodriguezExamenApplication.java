package com.examen.DiegoRodriguezExamen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiegoRodriguezExamenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiegoRodriguezExamenApplication.class, args);
	}

}
