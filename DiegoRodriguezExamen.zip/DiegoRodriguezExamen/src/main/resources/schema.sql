CREATE TABLE IF NOT EXISTS ENTRENADOR (
   id bigint primary key auto_increment,
   nombre varchar(50),
   active boolean DEFAULT false
);

CREATE TABLE IF NOT EXISTS REGION (
   id bigint primary key auto_increment,
   nombre varchar(25)
);

CREATE TABLE IF NOT EXISTS POKEMON (
   id bigint primary key auto_increment,
   nombre varchar(50),
   region INT,
   entrenador_id bigint,
   FOREIGN KEY (region) REFERENCES REGION(id) ON DELETE CASCADE,
   FOREIGN KEY (entrenador_id) REFERENCES ENTRENADOR(id)
);