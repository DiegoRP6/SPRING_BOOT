//entrenadores
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Ash', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Misty', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Brock', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('May', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Max', 0);
INSERT INTO REGION (nombre) VALUES ('Kanto');
INSERT INTO REGION (nombre) VALUES ('Johto');
INSERT INTO REGION (nombre) VALUES ('Hoenn');
INSERT INTO REGION (nombre) VALUES ('Sinnoh');
INSERT INTO REGION (nombre) VALUES ('Teselia');
INSERT INTO REGION (nombre) VALUES ('Kalos');
INSERT INTO REGION (nombre) VALUES ('Alola');
INSERT INTO REGION (nombre) VALUES ('Galar');
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Bulbasaur', 1, 1);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Charmander', 1, 1);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Squirtle', 1, 1);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Chikorita', 2, 2);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Cyndaquil', 2, 2);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Totodile', 2, 2);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Treecko', 3, 3);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Torchic', 3, 3);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Mudkip', 3, 3);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Turtwig', 4, 4);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Chimchar', 4, 4);
INSERT INTO POKEMON (nombre, region, entrenador_id) VALUES ('Piplup', 4, 4);

