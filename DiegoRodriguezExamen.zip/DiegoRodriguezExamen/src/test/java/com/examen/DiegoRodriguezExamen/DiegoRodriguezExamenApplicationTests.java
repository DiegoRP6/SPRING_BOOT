package com.examen.DiegoRodriguezExamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiegoRodriguezExamenApplicationTests {

	@Test
	void contextLoads() {
	}

}
